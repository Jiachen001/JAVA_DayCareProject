public class Student extends Person {
    private String fatherName;
    private String motherName;
    private double grade;

    public Student() {

    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Student{" +
                "personID=" + getPersonID() +
                ", schoolID=" + getSchoolID() +
                ", name='" + getName() + '\'' +
                ", ageMonths=" + getAgeMonths() +
                ", address='" + getAddress() + '\'' +
                ", phone='" + getPhone() + '\'' +
                ", fatherName='" + fatherName + '\'' +
                ", motherName='" + motherName + '\'' +
                ", grade=" + grade +
                '}';
    }
}
