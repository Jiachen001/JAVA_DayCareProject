import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Teacher extends Person {
    private int credit;
    private long lastTimeAnnualReview=-1;

    public Teacher() {
    }

    public long getLastTimeAnnualReview() {
        return lastTimeAnnualReview;
    }

    public void setLastTimeAnnualReview(long lastTimeAnnualReview) {
        this.lastTimeAnnualReview = lastTimeAnnualReview;
    }

    public int getCredit() {
        return credit;
    }
    public void setCredit(int credit) {
        this.credit = credit;
    }

    @Override
    public String toString() {
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String stringDate = sdf.format(lastTimeAnnualReview);
        return "Teacher{" +
                "personID=" + getPersonID() +
                ", schoolID=" + getSchoolID() +
                ", name='" + getName() + '\'' +
                ", ageMonths=" + getAgeMonths() +
                ", address='" + getAddress() + '\'' +
                ", phone='" + getPhone() + '\'' +
                ", credit=" + credit +
                ", lastTimeAnnualReview=" + stringDate +
                '}';
    }
}
