public class TestDriver {
    public static void  main(String[] args){
        DayCare dayCare=new DayCare();
//        dayCare.demo();
        dayCare.demo2();
    }
}
