public abstract class AbstractPersonFactory {
    abstract Person getObject();
}
